<?php
session_start();
if (!empty($_SESSION['user_id'])) {
    header('Location: /kghbms/dashboard.php');
} else {
    header('Location: /kghbms/login.php');
}
exit;
