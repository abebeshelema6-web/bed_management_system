<?php
$pageTitle = 'Manage Beds';
require_once __DIR__ . '/../includes/header.php';
require_role(['ADMINISTRATOR','NURSE','RECEPTION','DOCTOR','MANAGER']);

$filterStatus = $_GET['status'] ?? '';
$filterWard   = (int)($_GET['ward'] ?? 0);
$q            = trim($_GET['q'] ?? '');
$page = max(1,(int)($_GET['page'] ?? 1));
$perPage = 20;
$offset  = ($page-1)*$perPage;

$where = 'b.is_active=1';
$params = [];
if ($filterStatus) { $where .= ' AND b.current_status=?'; $params[] = $filterStatus; }
if ($filterWard)   { $where .= ' AND w.ward_id=?'; $params[] = $filterWard; }
if ($q)            { $where .= ' AND b.bed_number LIKE ?'; $params[] = "%$q%"; }

$total = $pdo->prepare("SELECT COUNT(*) FROM beds b JOIN rooms r ON r.room_id=b.room_id JOIN wards w ON w.ward_id=r.ward_id WHERE $where");
$total->execute($params); $totalCount=(int)$total->fetchColumn();

$stmt = $pdo->prepare("
    SELECT b.*, r.room_number, r.room_type, w.name AS ward_name, w.ward_id, d.name AS dept_name,
           p.full_name AS patient_name, p.patient_id, adm.admission_id AS active_admission_id, ba.allocated_at
    FROM beds b JOIN rooms r ON r.room_id=b.room_id AND r.status='ACTIVE'
    JOIN wards w ON w.ward_id=r.ward_id JOIN departments d ON d.department_id=w.department_id
    LEFT JOIN bed_allocations ba ON ba.bed_id=b.bed_id AND ba.is_active=1
    LEFT JOIN admissions adm ON adm.admission_id=ba.admission_id
    LEFT JOIN patients p ON p.patient_id=adm.patient_id
    WHERE $where ORDER BY w.name, r.room_number, b.bed_number LIMIT $perPage OFFSET $offset
");
$stmt->execute($params); $beds = $stmt->fetchAll();
$pag = paginate($totalCount,$perPage,$page);

$wards    = $pdo->query("SELECT w.ward_id, w.name, d.name AS dept FROM wards w JOIN departments d ON d.department_id=w.department_id WHERE w.status='ACTIVE' ORDER BY d.name,w.name")->fetchAll();
$statuses = ['AVAILABLE','OCCUPIED','RESERVED','CLEANING','MAINTENANCE','BLOCKED','OUT_OF_SERVICE'];
?>
<div class="page-header">
    <div><h1><i class="fas fa-hospital-alt me-2 text-primary"></i>Manage Beds</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item active">Beds</li></ol></nav></div>
    <?php if (has_role(['ADMINISTRATOR','MANAGER'])): ?>
    <a href="/kghbms/beds/add.php" class="btn btn-primary"><i class="fas fa-plus me-1"></i>Add Bed</a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
        <form class="d-flex flex-wrap gap-2 align-items-center" method="get">
            <input type="text" name="q" class="form-control form-control-sm" style="width:160px;" placeholder="Bed number…" value="<?= e($q) ?>">
            <select name="ward" class="form-select form-select-sm" style="width:200px;">
                <option value="">All Wards</option>
                <?php foreach ($wards as $w): ?>
                <option value="<?= $w['ward_id'] ?>" <?= $filterWard==$w['ward_id']?'selected':'' ?>><?= e($w['dept'].' › '.$w['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="status" class="form-select form-select-sm" style="width:160px;">
                <option value="">All Statuses</option>
                <?php foreach ($statuses as $s): ?>
                <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-search me-1"></i>Filter</button>
            <a href="?" class="btn btn-sm btn-outline-secondary">Reset</a>
            <span class="ms-auto text-muted small"><?= $totalCount ?> bed(s)</span>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead><tr><th>Bed No.</th><th>Type</th><th>Ward / Room</th><th>Status</th><th>Patient</th><th>Allocated</th><th>Actions</th></tr></thead>
            <tbody>
                <?php foreach ($beds as $b): ?>
                <tr>
                    <td class="fw-semibold"><?= e($b['bed_number']) ?></td>
                    <td><span class="badge bg-light text-dark border"><?= e($b['bed_type']) ?></span></td>
                    <td class="small"><?= e($b['ward_name']) ?><br><span class="text-muted"><?= e($b['room_number']) ?></span></td>
                    <td><?= status_badge($b['current_status']) ?></td>
                    <td class="small">
                        <?php if ($b['patient_name'] && (!has_role(['NURSE']) || ($b['active_admission_id'] && is_admission_assigned_to_nurse($pdo, (int)$b['active_admission_id'], current_user_id())))): ?>
                        <a href="/kghbms/patients/view.php?id=<?= $b['patient_id'] ?>" class="text-decoration-none"><?= e($b['patient_name']) ?></a>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="small text-muted"><?= $b['allocated_at'] ? date('d/m H:i',strtotime($b['allocated_at'])) : '—' ?></td>
                    <td>
                        <div class="d-flex gap-1">
                            <button class="btn btn-sm btn-outline-info" onclick="openBedDetail(<?= $b['bed_id'] ?>)" title="Details"><i class="fas fa-info-circle"></i></button>
                            <?php if (has_role(['ADMINISTRATOR','NURSE','MANAGER'])): ?>
                            <a href="/kghbms/beds/change_status.php?bed_id=<?= $b['bed_id'] ?>" class="btn btn-sm btn-outline-warning" title="Change Status"><i class="fas fa-cog"></i></a>
                            <?php endif; ?>
                            <?php if (has_role(['ADMINISTRATOR','MANAGER'])): ?>
                            <a href="/kghbms/beds/edit.php?id=<?= $b['bed_id'] ?>" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fas fa-edit"></i></a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($beds)): ?>
                <tr><td colspan="7" class="text-center text-muted py-4"><i class="fas fa-bed fa-2x mb-2 d-block"></i>No beds found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pag['pages'] > 1): ?>
    <div class="card-footer d-flex justify-content-between align-items-center">
        <div class="text-muted small">Showing <?= $offset+1 ?>–<?= min($offset+$perPage,$totalCount) ?> of <?= $totalCount ?></div>
        <?= pagination_links($pag, '?ward='.urlencode($filterWard).'&status='.urlencode($filterStatus).'&q='.urlencode($q)) ?>
    </div>
    <?php endif; ?>
</div>

<!-- Bed Detail Modal -->
<div class="modal fade" id="bedDetailModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" id="bedDetailContent"></div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
