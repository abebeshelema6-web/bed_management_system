<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_login();
$pdo = getDB();
require_role(['ADMINISTRATOR']);

if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $uid = (int)$_GET['toggle'];
    if ($uid !== current_user_id()) {
        $s = $pdo->prepare('SELECT status FROM users WHERE user_id=?'); $s->execute([$uid]); $s=$s->fetch();
        $new = $s['status']==='ACTIVE' ? 'INACTIVE' : 'ACTIVE';
        $pdo->prepare('UPDATE users SET status=? WHERE user_id=?')->execute([$new,$uid]);
        audit($pdo, current_user_id(), 'TOGGLE_USER_STATUS', 'users', $uid, "Status → $new");
        set_flash('success', "User status changed to <strong>$new</strong>.");
    }
    header('Location: /kghbms/users/list.php'); exit;
}

if (isset($_GET['unlock']) && is_numeric($_GET['unlock'])) {
    $uid = (int)$_GET['unlock'];
    $pdo->prepare("UPDATE users SET status='ACTIVE', failed_attempts=0 WHERE user_id=?")->execute([$uid]);
    audit($pdo, current_user_id(), 'UNLOCK_USER', 'users', $uid);
    set_flash('success','User account unlocked.');
    header('Location: /kghbms/users/list.php'); exit;
}

$roles  = $pdo->query("SELECT * FROM roles ORDER BY role_name")->fetchAll();
$users  = $pdo->query("SELECT u.*, r.role_name FROM users u JOIN roles r ON r.role_id=u.role_id ORDER BY r.role_name, u.full_name")->fetchAll();
$errors = [];
$form   = ['status' => 'ACTIVE'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $form = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'username'  => trim($_POST['username'] ?? ''),
        'email'     => trim($_POST['email'] ?? ''),
        'phone'     => trim($_POST['phone'] ?? ''),
        'role_id'   => (int)($_POST['role_id'] ?? 0),
        'password'  => $_POST['password'] ?? '',
        'status'    => $_POST['status'] ?? 'ACTIVE',
    ];
    if (!$form['full_name'])           $errors[] = 'Full name is required.';
    if (!$form['username'])            $errors[] = 'Username is required.';
    if (!$form['role_id'])             $errors[] = 'Role is required.';
    if (strlen($form['password']) < 8) $errors[] = 'Password must be at least 8 characters.';
    if (!preg_match('/[A-Za-z]/', $form['password']))   $errors[] = 'Password must contain a letter.';
    if (!preg_match('/[0-9@#$!_]/', $form['password'])) $errors[] = 'Password must contain a number or symbol.';

    if (empty($errors)) {
        try {
            $hash = password_hash($form['password'], PASSWORD_DEFAULT);
            $pdo->prepare('INSERT INTO users (role_id,username,password_hash,full_name,email,phone,status) VALUES (?,?,?,?,?,?,?)')
                ->execute([$form['role_id'],$form['username'],$hash,$form['full_name'],$form['email']?:null,$form['phone']?:null,$form['status']]);
            audit($pdo, current_user_id(), 'CREATE_USER', 'users', (int)$pdo->lastInsertId(), "Created: {$form['username']}");
            set_flash('success', "User <strong>{$form['full_name']}</strong> created.");
            header('Location: /kghbms/users/list.php'); exit;
        } catch (PDOException $e) {
            $errors[] = str_contains($e->getMessage(),'Duplicate') ? 'Username or email already exists.' : $e->getMessage();
        }
    }
}

$roleColors = ['ADMINISTRATOR'=>'danger','RECEPTION'=>'primary','NURSE'=>'success','DOCTOR'=>'info','MANAGER'=>'warning'];
$pageTitle  = 'User Management';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div><h1><i class="fas fa-user-shield me-2 text-primary"></i>User Management</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item active">Users</li></ol></nav></div>
</div>
<div class="row g-4">
    <div class="col-12 col-lg-4">
        <div class="card">
            <div class="card-header"><i class="fas fa-user-plus me-2"></i>Add New User</div>
            <div class="card-body">
                <?php if ($errors): ?><div class="alert alert-danger small"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
                <form method="post" data-loading><?= csrf_field() ?>
                    <div class="mb-2"><label class="form-label small fw-semibold">Full Name <span class="required-mark">*</span></label>
                    <input type="text" name="full_name" class="form-control form-control-sm" required maxlength="100" value="<?= e($form['full_name']??'') ?>"></div>
                    <div class="mb-2"><label class="form-label small fw-semibold">Username <span class="required-mark">*</span></label>
                    <input type="text" name="username" class="form-control form-control-sm" required maxlength="50" value="<?= e($form['username']??'') ?>"></div>
                    <div class="mb-2"><label class="form-label small fw-semibold">Role <span class="required-mark">*</span></label>
                    <select name="role_id" class="form-select form-select-sm" required>
                        <option value="">Select role…</option>
                        <?php foreach ($roles as $r): ?><option value="<?= $r['role_id'] ?>" <?= ($form['role_id']??0)==$r['role_id']?'selected':'' ?>><?= e($r['role_name']) ?></option><?php endforeach; ?>
                    </select></div>
                    <div class="mb-2"><label class="form-label small fw-semibold">Email</label>
                    <input type="email" name="email" class="form-control form-control-sm" value="<?= e($form['email']??'') ?>"></div>
                    <div class="mb-2"><label class="form-label small fw-semibold">Phone</label>
                    <input type="tel" name="phone" class="form-control form-control-sm" value="<?= e($form['phone']??'') ?>"></div>
                    <div class="mb-2"><label class="form-label small fw-semibold">Password <span class="required-mark">*</span></label>
                    <input type="password" name="password" class="form-control form-control-sm" required minlength="8">
                    <div class="form-text">Min 8 chars, letter + number/symbol.</div></div>
                    <div class="mb-3"><label class="form-label small fw-semibold">Status</label>
                    <select name="status" class="form-select form-select-sm">
                        <option value="ACTIVE">ACTIVE</option><option value="INACTIVE">INACTIVE</option>
                    </select></div>
                    <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-save me-1"></i>Create User</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="fas fa-users me-2"></i>System Users</span>
                <span class="badge bg-secondary"><?= count($users) ?></span>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($users as $u): $rc=$roleColors[$u['role_name']]??'secondary'; ?>
                        <tr class="<?= $u['status']==='INACTIVE'?'table-light text-muted':'' ?>">
                            <td><div class="fw-semibold small"><?= e($u['full_name']) ?></div>
                                <div class="text-muted" style="font-size:.72rem"><?= e($u['email']??'') ?></div></td>
                            <td><code class="small"><?= e($u['username']) ?></code></td>
                            <td><span class="badge bg-<?= $rc ?>"><?= e($u['role_name']) ?></span></td>
                            <td>
                                <?php if ($u['status']==='LOCKED'): ?><span class="badge bg-danger"><i class="fas fa-lock me-1"></i>LOCKED</span>
                                <?php elseif ($u['status']==='ACTIVE'): ?><span class="badge bg-success">ACTIVE</span>
                                <?php else: ?><span class="badge bg-secondary">INACTIVE</span><?php endif; ?>
                                <?php if ($u['failed_attempts']>0): ?><span class="badge bg-warning text-dark ms-1"><?= $u['failed_attempts'] ?>✗</span><?php endif; ?>
                            </td>
                            <td class="small text-muted"><?= $u['last_login']?date('d/m/Y H:i',strtotime($u['last_login'])):'Never' ?></td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="/kghbms/users/edit.php?id=<?= $u['user_id'] ?>" class="btn btn-xs btn-outline-warning p-1" title="Edit"><i class="fas fa-edit"></i></a>
                                    <?php if ($u['user_id']!==current_user_id()): ?>
                                        <?php if ($u['status']==='LOCKED'||$u['failed_attempts']>0): ?>
                                        <a href="?unlock=<?= $u['user_id'] ?>" class="btn btn-xs btn-outline-success p-1" title="Unlock" data-confirm="Unlock this account?"><i class="fas fa-unlock"></i></a>
                                        <?php endif; ?>
                                        <a href="?toggle=<?= $u['user_id'] ?>"
                                           class="btn btn-xs btn-outline-<?= $u['status']==='ACTIVE'?'danger':'success' ?> p-1"
                                           data-confirm="<?= $u['status']==='ACTIVE'?'Deactivate':'Activate' ?> this user?"
                                           title="<?= $u['status']==='ACTIVE'?'Deactivate':'Activate' ?>">
                                            <i class="fas fa-<?= $u['status']==='ACTIVE'?'ban':'check' ?>"></i></a>
                                    <?php else: ?><span class="badge bg-light text-muted border">You</span><?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
