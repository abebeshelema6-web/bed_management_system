<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_login();
$pdo = getDB();
require_role(['ADMINISTRATOR']);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: /kghbms/users/list.php'); exit; }

$userRow = $pdo->prepare('SELECT u.*, r.role_name FROM users u JOIN roles r ON r.role_id=u.role_id WHERE u.user_id=?');
$userRow->execute([$id]); $u = $userRow->fetch();
if (!$u) { set_flash('danger','User not found.'); header('Location: /kghbms/users/list.php'); exit; }

$roles  = $pdo->query("SELECT * FROM roles ORDER BY role_name")->fetchAll();
$errors = [];
$form   = $u;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $form = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'email'     => trim($_POST['email'] ?? ''),
        'phone'     => trim($_POST['phone'] ?? ''),
        'role_id'   => (int)($_POST['role_id'] ?? 0),
        'status'    => $_POST['status'] ?? 'ACTIVE',
    ];
    $newPwd = $_POST['new_password'] ?? '';
    if (!$form['full_name']) $errors[] = 'Full name is required.';
    if (!$form['role_id'])   $errors[] = 'Role is required.';
    if ($newPwd && strlen($newPwd) < 8) $errors[] = 'New password must be at least 8 characters.';

    if (empty($errors)) {
        if ($newPwd) {
            $hash = password_hash($newPwd, PASSWORD_DEFAULT);
            $pdo->prepare('UPDATE users SET role_id=?,full_name=?,email=?,phone=?,status=?,password_hash=?,failed_attempts=0 WHERE user_id=?')
                ->execute([$form['role_id'],$form['full_name'],$form['email']?:null,$form['phone']?:null,$form['status'],$hash,$id]);
        } else {
            $pdo->prepare('UPDATE users SET role_id=?,full_name=?,email=?,phone=?,status=? WHERE user_id=?')
                ->execute([$form['role_id'],$form['full_name'],$form['email']?:null,$form['phone']?:null,$form['status'],$id]);
        }
        audit($pdo, current_user_id(), 'UPDATE_USER', 'users', $id, "Updated: {$u['username']}".($newPwd?' +pwd':''));
        set_flash('success','User updated successfully.');
        header('Location: /kghbms/users/list.php'); exit;
    }
}

$pageTitle = 'Edit User';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div><h1><i class="fas fa-user-edit me-2 text-warning"></i>Edit User</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/kghbms/users/list.php">Users</a></li>
        <li class="breadcrumb-item active"><?= e($u['username']) ?></li>
    </ol></nav></div>
</div>
<div class="row justify-content-center">
<div class="col-12 col-md-6">
<div class="card">
    <div class="card-header"><i class="fas fa-user me-2"></i><?= e($u['full_name']) ?> <code class="ms-2 small"><?= e($u['username']) ?></code></div>
    <div class="card-body">
        <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" data-loading>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label fw-semibold">Full Name <span class="required-mark">*</span></label>
            <input type="text" name="full_name" class="form-control" required maxlength="100" value="<?= e($form['full_name']) ?>"></div>
            <div class="mb-3"><label class="form-label fw-semibold">Role <span class="required-mark">*</span></label>
            <select name="role_id" class="form-select" required>
                <?php foreach ($roles as $r): ?><option value="<?= $r['role_id'] ?>" <?= $form['role_id']==$r['role_id']?'selected':'' ?>><?= e($r['role_name']) ?></option><?php endforeach; ?>
            </select></div>
            <div class="mb-3"><label class="form-label fw-semibold">Email</label>
            <input type="email" name="email" class="form-control" value="<?= e($form['email']??'') ?>"></div>
            <div class="mb-3"><label class="form-label fw-semibold">Phone</label>
            <input type="tel" name="phone" class="form-control" value="<?= e($form['phone']??'') ?>"></div>
            <div class="mb-3"><label class="form-label fw-semibold">Status</label>
            <select name="status" class="form-select">
                <option value="ACTIVE" <?= $form['status']==='ACTIVE'?'selected':'' ?>>ACTIVE</option>
                <option value="INACTIVE" <?= $form['status']==='INACTIVE'?'selected':'' ?>>INACTIVE</option>
            </select></div>
            <div class="mb-4"><label class="form-label fw-semibold">New Password <span class="text-muted small fw-normal">(leave blank to keep current)</span></label>
            <input type="password" name="new_password" class="form-control" minlength="8" placeholder="Enter new password to change…"></div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-warning"><i class="fas fa-save me-1"></i>Save Changes</button>
                <a href="/kghbms/users/list.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
