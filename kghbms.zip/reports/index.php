<?php
$pageTitle = 'Reports';
require_once __DIR__ . '/../includes/header.php';
require_role(['ADMINISTRATOR','MANAGER','RECEPTION','DOCTOR','NURSE']);

$report = $_GET['report'] ?? 'occupancy';
$from   = $_GET['from']   ?? date('Y-m-01');
$to     = $_GET['to']     ?? date('Y-m-d');
$wardId = (int)($_GET['ward'] ?? 0);

$wards = $pdo->query("SELECT w.ward_id, w.name, d.name AS dept FROM wards w
    JOIN departments d ON d.department_id=w.department_id
    WHERE w.status='ACTIVE' ORDER BY d.name,w.name")->fetchAll();

$reportTypes = [
    'occupancy'   => ['icon'=>'fa-chart-pie',    'label'=>'Bed Occupancy'],
    'available'   => ['icon'=>'fa-check-circle', 'label'=>'Available Beds'],
    'admissions'  => ['icon'=>'fa-procedures',   'label'=>'Admissions'],
    'discharges'  => ['icon'=>'fa-sign-out-alt', 'label'=>'Discharges'],
    'transfers'   => ['icon'=>'fa-exchange-alt', 'label'=>'Transfers'],
    'utilization' => ['icon'=>'fa-chart-bar',    'label'=>'Utilization'],
    'ward'        => ['icon'=>'fa-layer-group',  'label'=>'Ward Summary'],
];

$isSnapshot = in_array($report, ['occupancy','available','ward']);
$data = [];

switch ($report) {
    case 'occupancy':
        $sql = "SELECT w.name AS ward_name, d.name AS dept_name,
                    COUNT(b.bed_id) AS total,
                    SUM(b.current_status='OCCUPIED') AS occupied,
                    SUM(b.current_status='AVAILABLE') AS available,
                    SUM(b.current_status='RESERVED') AS reserved,
                    SUM(b.current_status='CLEANING') AS cleaning,
                    SUM(b.current_status='MAINTENANCE') AS maintenance,
                    ROUND(100*SUM(b.current_status='OCCUPIED')/NULLIF(SUM(b.current_status NOT IN ('MAINTENANCE','BLOCKED','OUT_OF_SERVICE')),0),1) AS occ_rate
                FROM beds b
                JOIN rooms r ON r.room_id=b.room_id
                JOIN wards w ON w.ward_id=r.ward_id AND w.status='ACTIVE'
                JOIN departments d ON d.department_id=w.department_id
                WHERE b.is_active=1";
        $p=[];
        if ($wardId) { $sql.=' AND w.ward_id=?'; $p[]=$wardId; }
        $sql.=' GROUP BY w.ward_id ORDER BY d.name,w.name';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;

    case 'available':
        $sql = "SELECT b.bed_number, b.bed_type, r.room_number,
                    w.name AS ward_name, d.name AS dept_name, b.notes
                FROM beds b
                JOIN rooms r ON r.room_id=b.room_id AND r.status='ACTIVE'
                JOIN wards w ON w.ward_id=r.ward_id AND w.status='ACTIVE'
                JOIN departments d ON d.department_id=w.department_id
                WHERE b.is_active=1 AND b.current_status='AVAILABLE'";
        $p=[];
        if ($wardId) { $sql.=' AND w.ward_id=?'; $p[]=$wardId; }
        $sql.=' ORDER BY w.name,r.room_number,b.bed_number';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;

    case 'admissions':
        $sql = "SELECT a.admission_id, p.full_name, p.patient_number, p.gender,
                    a.admission_type, a.admission_date, a.status,
                    d.name AS dept_name, b.bed_number, w.name AS ward_name,
                    doc.full_name AS doctor_name
                FROM admissions a
                JOIN patients p ON p.patient_id=a.patient_id
                JOIN departments d ON d.department_id=a.department_id
                LEFT JOIN bed_allocations ba ON ba.admission_id=a.admission_id AND ba.is_active=1
                LEFT JOIN beds b ON b.bed_id=ba.bed_id
                LEFT JOIN rooms r ON r.room_id=b.room_id
                LEFT JOIN wards w ON w.ward_id=r.ward_id
                LEFT JOIN users doc ON doc.user_id=a.attending_doctor_id
                WHERE DATE(a.admission_date) BETWEEN ? AND ?";
        $p=[$from,$to];
        if ($wardId) { $sql.=' AND w.ward_id=?'; $p[]=$wardId; }
        if (has_role(['NURSE'])) {
            $sql.=' AND EXISTS (SELECT 1 FROM admission_nurse_assignments ana WHERE ana.admission_id=a.admission_id AND ana.nurse_user_id=?)';
            $p[]=current_user_id();
        }
        $sql.=' ORDER BY a.admission_date DESC';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;

    case 'discharges':
        $sql = "SELECT dis.*, p.full_name, p.patient_number, p.gender,
                    a.admission_date, a.admission_type, d.name AS dept_name,
                    GREATEST(0,TIMESTAMPDIFF(DAY,a.admission_date,dis.discharge_date)) AS los_days,
                    u.full_name AS by_name
                FROM discharges dis
                JOIN patients p ON p.patient_id=dis.patient_id
                JOIN admissions a ON a.admission_id=dis.admission_id
                JOIN departments d ON d.department_id=a.department_id
                JOIN users u ON u.user_id=dis.discharged_by
                WHERE DATE(dis.discharge_date) BETWEEN ? AND ?";
        $p=[$from,$to];
        if (has_role(['NURSE'])) {
            $sql.=' AND EXISTS (SELECT 1 FROM admission_nurse_assignments ana WHERE ana.admission_id=a.admission_id AND ana.nurse_user_id=?)';
            $p[]=current_user_id();
        }
        $sql.=' ORDER BY dis.discharge_date DESC';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;

    case 'transfers':
        $sql = "SELECT bt.transfer_id, p.full_name, p.patient_number,
                    bf.bed_number AS from_bed, wf.name AS from_ward,
                    bt2.bed_number AS to_bed, wt.name AS to_ward,
                    bt.transfer_date, bt.reason, u.full_name AS by_name
                FROM bed_transfers bt
                JOIN patients p ON p.patient_id=bt.patient_id
                JOIN beds bf ON bf.bed_id=bt.from_bed_id
                JOIN rooms rf ON rf.room_id=bf.room_id
                JOIN wards wf ON wf.ward_id=rf.ward_id
                JOIN beds bt2 ON bt2.bed_id=bt.to_bed_id
                JOIN rooms rt ON rt.room_id=bt2.room_id
                JOIN wards wt ON wt.ward_id=rt.ward_id
                JOIN users u ON u.user_id=bt.transferred_by
                WHERE DATE(bt.transfer_date) BETWEEN ? AND ?";
        $p=[$from,$to];
        if ($wardId) { $sql.=' AND (wf.ward_id=? OR wt.ward_id=?)'; $p[]=$wardId;$p[]=$wardId; }
        if (has_role(['NURSE'])) {
            $sql.=' AND EXISTS (SELECT 1 FROM admission_nurse_assignments ana WHERE ana.admission_id=bt.admission_id AND ana.nurse_user_id=?)';
            $p[]=current_user_id();
        }
        $sql.=' ORDER BY bt.transfer_date DESC';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;

    case 'utilization':
        $sql = "SELECT w.name AS ward_name, d.name AS dept_name,
                    b.bed_number, b.bed_type,
                    COUNT(ba.allocation_id) AS total_stays,
                    ROUND(AVG(TIMESTAMPDIFF(HOUR,ba.allocated_at,COALESCE(ba.released_at,NOW())))/24,1) AS avg_los,
                    COALESCE(SUM(TIMESTAMPDIFF(HOUR,ba.allocated_at,COALESCE(ba.released_at,NOW()))),0) AS total_hours
                FROM beds b
                JOIN rooms r ON r.room_id=b.room_id
                JOIN wards w ON w.ward_id=r.ward_id
                JOIN departments d ON d.department_id=w.department_id
                LEFT JOIN bed_allocations ba ON ba.bed_id=b.bed_id
                    AND DATE(ba.allocated_at) BETWEEN ? AND ?
                WHERE b.is_active=1";
        $p=[$from,$to];
        if ($wardId) { $sql.=' AND w.ward_id=?'; $p[]=$wardId; }
        $sql.=' GROUP BY b.bed_id ORDER BY w.name,b.bed_number';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;

    case 'ward':
        $sql = "SELECT w.name AS ward_name, w.ward_type, w.capacity, d.name AS dept_name,
                    COUNT(DISTINCT b.bed_id) AS total_beds,
                    COALESCE(SUM(b.current_status='OCCUPIED'),0) AS occupied,
                    COALESCE(SUM(b.current_status='AVAILABLE'),0) AS available,
                    COALESCE(SUM(b.current_status='RESERVED'),0) AS reserved,
                    COALESCE(SUM(b.current_status='CLEANING'),0) AS cleaning,
                    COALESCE(SUM(b.current_status='MAINTENANCE'),0) AS maintenance,
                    COUNT(DISTINCT ba.admission_id) AS active_patients
                FROM wards w
                JOIN departments d ON d.department_id=w.department_id
                LEFT JOIN rooms r ON r.ward_id=w.ward_id
                LEFT JOIN beds b ON b.room_id=r.room_id AND b.is_active=1
                LEFT JOIN bed_allocations ba ON ba.bed_id=b.bed_id AND ba.is_active=1
                WHERE w.status='ACTIVE'";
        $p=[];
        if ($wardId) { $sql.=' AND w.ward_id=?'; $p[]=$wardId; }
        $sql.=' GROUP BY w.ward_id ORDER BY d.name,w.name';
        $s=$pdo->prepare($sql);$s->execute($p);$data=$s->fetchAll();
        break;
}
?>
<div class="page-header">
    <div>
        <h1><i class="fas fa-chart-bar me-2 text-primary"></i>Reports</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item active">Reports</li></ol></nav>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-secondary btn-sm" data-print>
            <i class="fas fa-print me-1"></i>Print
        </button>
        <a href="#" class="btn btn-outline-success btn-sm" id="exportCsvBtn">
            <i class="fas fa-file-csv me-1"></i>Export CSV
        </a>
    </div>
</div>

<!-- Report type tabs -->
<div class="d-flex flex-wrap gap-2 mb-3">
    <?php foreach ($reportTypes as $key => $rt): ?>
    <a href="?report=<?= $key ?>&from=<?= urlencode($from) ?>&to=<?= urlencode($to) ?>&ward=<?= $wardId ?>"
       class="btn btn-sm btn-<?= $report===$key?'primary':'outline-secondary' ?>">
        <i class="fas <?= $rt['icon'] ?> me-1"></i><?= $rt['label'] ?>
    </a>
    <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form class="row g-2 align-items-end" method="get">
            <input type="hidden" name="report" value="<?= e($report) ?>">
            <?php if (!$isSnapshot): ?>
            <div class="col-auto">
                <label class="form-label small mb-0">From</label>
                <input type="date" name="from" class="form-control form-control-sm" value="<?= e($from) ?>">
            </div>
            <div class="col-auto">
                <label class="form-label small mb-0">To</label>
                <input type="date" name="to" class="form-control form-control-sm" value="<?= e($to) ?>">
            </div>
            <?php endif; ?>
            <div class="col-auto">
                <label class="form-label small mb-0">Ward</label>
                <select name="ward" class="form-select form-select-sm" style="min-width:190px">
                    <option value="">All Wards</option>
                    <?php foreach ($wards as $w): ?>
                    <option value="<?= $w['ward_id'] ?>" <?= $wardId==$w['ward_id']?'selected':'' ?>><?= e($w['dept'].' › '.$w['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-sync me-1"></i>Generate</button>
            </div>
            <div class="col-auto ms-auto text-muted small d-flex align-items-center">
                <?= $isSnapshot ? 'Current snapshot' : e($from).' – '.e($to) ?>
                &nbsp;·&nbsp; <?= count($data) ?> record(s)
            </div>
        </form>
    </div>
</div>

<!-- Report output -->
<div class="card" id="reportOutput">
    <div class="card-header fw-semibold">
        <i class="fas <?= $reportTypes[$report]['icon'] ?? 'fa-table' ?> me-2 text-primary"></i>
        <?= $reportTypes[$report]['label'] ?? '' ?>
        <span class="badge bg-secondary ms-2"><?= count($data) ?></span>
    </div>
    <div class="table-responsive">
    <?php if (empty($data)): ?>
        <div class="text-center text-muted py-5">
            <i class="fas fa-chart-bar fa-3x mb-3 d-block opacity-25"></i>
            No data found for the selected criteria.
        </div>

    <?php elseif ($report === 'occupancy'): ?>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>Ward</th><th>Department</th><th>Total</th><th>Occupied</th><th>Available</th><th>Reserved</th><th>Cleaning</th><th>Maint.</th><th>Occupancy %</th></tr></thead>
            <tbody>
            <?php
            $tot = array_fill_keys(['total','occupied','available','reserved','cleaning','maintenance'],0);
            foreach ($data as $r):
                foreach ($tot as $k=>$v) $tot[$k]+=(int)$r[$k];
            ?>
            <tr>
                <td class="fw-semibold"><?= e($r['ward_name']) ?></td>
                <td class="small"><?= e($r['dept_name']) ?></td>
                <td><?= $r['total'] ?></td>
                <td><span class="badge bg-danger"><?= $r['occupied'] ?></span></td>
                <td><span class="badge bg-success"><?= $r['available'] ?></span></td>
                <td><span class="badge bg-warning text-dark"><?= $r['reserved'] ?></span></td>
                <td><span class="badge bg-info"><?= $r['cleaning'] ?></span></td>
                <td><span class="badge bg-purple"><?= $r['maintenance'] ?></span></td>
                <td>
                    <div class="d-flex align-items-center gap-2">
                        <div class="progress flex-grow-1" style="height:8px">
                            <div class="progress-bar bg-<?= (float)$r['occ_rate']>=90?'danger':((float)$r['occ_rate']>=70?'warning':'success') ?>"
                                 style="width:<?= $r['occ_rate'] ?>%"></div>
                        </div>
                        <strong><?= $r['occ_rate'] ?>%</strong>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <tr class="table-dark fw-bold">
                <td colspan="2">TOTAL</td>
                <td><?= $tot['total'] ?></td>
                <td><?= $tot['occupied'] ?></td>
                <td><?= $tot['available'] ?></td>
                <td><?= $tot['reserved'] ?></td>
                <td><?= $tot['cleaning'] ?></td>
                <td><?= $tot['maintenance'] ?></td>
                <td><?= $tot['total']>0?round($tot['occupied']/$tot['total']*100,1):0 ?>%</td>
            </tr>
            </tbody>
        </table>

    <?php elseif ($report === 'available'): ?>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>Bed No.</th><th>Type</th><th>Room</th><th>Ward</th><th>Department</th><th>Notes</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr>
                <td class="fw-semibold"><?= e($r['bed_number']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= e($r['bed_type']) ?></span></td>
                <td><?= e($r['room_number']) ?></td>
                <td><?= e($r['ward_name']) ?></td>
                <td class="small"><?= e($r['dept_name']) ?></td>
                <td class="small text-muted"><?= e($r['notes'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($report === 'admissions'): ?>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>#</th><th>Patient</th><th>Gender</th><th>Type</th><th>Department</th><th>Bed/Ward</th><th>Doctor</th><th>Admitted</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr>
                <td class="text-muted small"><?= $r['admission_id'] ?></td>
                <td>
                    <div class="fw-semibold small"><?= e($r['full_name']) ?></div>
                    <div class="text-muted" style="font-size:.72rem"><?= e($r['patient_number']) ?></div>
                </td>
                <td class="small"><?= e($r['gender']) ?></td>
                <td><span class="badge bg-<?= $r['admission_type']==='EMERGENCY'?'danger':'primary' ?> small"><?= e($r['admission_type']) ?></span></td>
                <td class="small"><?= e($r['dept_name']) ?></td>
                <td class="small"><?= $r['bed_number'] ? e($r['bed_number'].' / '.$r['ward_name']) : '—' ?></td>
                <td class="small"><?= e($r['doctor_name'] ?? '—') ?></td>
                <td class="small text-muted"><?= date('d/m/Y H:i',strtotime($r['admission_date'])) ?></td>
                <td><?= status_badge($r['status']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($report === 'discharges'): ?>
        <?php
        $avgLos = count($data) ? round(array_sum(array_column($data,'los_days'))/count($data),1) : 0;
        $typeCounts = array_count_values(array_column($data,'discharge_type'));
        ?>
        <div class="px-3 py-2 bg-light border-bottom small d-flex flex-wrap gap-3">
            <span><strong>Total Discharges:</strong> <?= count($data) ?></span>
            <span><strong>Avg Length of Stay:</strong> <?= $avgLos ?> days</span>
            <?php foreach ($typeCounts as $t=>$c): ?>
            <span><span class="badge bg-secondary"><?= str_replace('_',' ',$t) ?>:</span> <?= $c ?></span>
            <?php endforeach; ?>
        </div>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>Patient</th><th>Gender</th><th>Type</th><th>Department</th><th>Admitted</th><th>Discharged</th><th>LOS (days)</th><th>By</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr>
                <td>
                    <div class="fw-semibold small"><?= e($r['full_name']) ?></div>
                    <div class="text-muted" style="font-size:.72rem"><?= e($r['patient_number']) ?></div>
                </td>
                <td class="small"><?= e($r['gender']) ?></td>
                <td><span class="badge bg-<?= $r['discharge_type']==='DECEASED'?'dark':($r['discharge_type']==='RECOVERED'?'success':'secondary') ?>"><?= str_replace('_',' ',e($r['discharge_type'])) ?></span></td>
                <td class="small"><?= e($r['dept_name']) ?></td>
                <td class="small text-muted"><?= date('d/m/Y',strtotime($r['admission_date'])) ?></td>
                <td class="small text-muted"><?= date('d/m/Y H:i',strtotime($r['discharge_date'])) ?></td>
                <td class="text-center"><span class="badge bg-light text-dark border"><?= (int)$r['los_days'] ?>d</span></td>
                <td class="small"><?= e($r['by_name']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($report === 'transfers'): ?>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>Patient</th><th>From Bed</th><th>From Ward</th><th>To Bed</th><th>To Ward</th><th>Date</th><th>Reason</th><th>By</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr>
                <td>
                    <div class="fw-semibold small"><?= e($r['full_name']) ?></div>
                    <div class="text-muted" style="font-size:.72rem"><?= e($r['patient_number']) ?></div>
                </td>
                <td><?= e($r['from_bed']) ?></td>
                <td class="small"><?= e($r['from_ward']) ?></td>
                <td><?= e($r['to_bed']) ?></td>
                <td class="small"><?= e($r['to_ward']) ?></td>
                <td class="small text-muted"><?= date('d/m/Y H:i',strtotime($r['transfer_date'])) ?></td>
                <td class="small"><?= e($r['reason']) ?></td>
                <td class="small"><?= e($r['by_name']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($report === 'utilization'): ?>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>Bed No.</th><th>Type</th><th>Ward</th><th>Department</th><th>Total Stays</th><th>Avg LOS (days)</th><th>Total Hours Occupied</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr>
                <td class="fw-semibold"><?= e($r['bed_number']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= e($r['bed_type']) ?></span></td>
                <td class="small"><?= e($r['ward_name']) ?></td>
                <td class="small"><?= e($r['dept_name']) ?></td>
                <td class="text-center"><span class="badge bg-primary"><?= (int)$r['total_stays'] ?></span></td>
                <td class="text-center"><?= $r['avg_los'] ?? 0 ?>d</td>
                <td class="text-center"><?= number_format((int)$r['total_hours']) ?>h</td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($report === 'ward'): ?>
        <table class="table table-hover mb-0" id="reportTable">
            <thead><tr><th>Ward</th><th>Type</th><th>Department</th><th>Beds</th><th>Occupied</th><th>Available</th><th>Reserved</th><th>Cleaning</th><th>Patients</th><th>Occ %</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r):
                $occ = $r['total_beds']>0 ? round($r['occupied']/$r['total_beds']*100,1) : 0;
            ?>
            <tr>
                <td class="fw-semibold"><?= e($r['ward_name']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= e($r['ward_type']) ?></span></td>
                <td class="small"><?= e($r['dept_name']) ?></td>
                <td><?= $r['total_beds'] ?></td>
                <td><span class="badge bg-danger"><?= $r['occupied'] ?></span></td>
                <td><span class="badge bg-success"><?= $r['available'] ?></span></td>
                <td><span class="badge bg-warning text-dark"><?= $r['reserved'] ?></span></td>
                <td><span class="badge bg-info"><?= $r['cleaning'] ?></span></td>
                <td class="fw-semibold text-center"><?= $r['active_patients'] ?></td>
                <td>
                    <div class="d-flex align-items-center gap-2">
                        <div class="progress flex-grow-1" style="height:8px">
                            <div class="progress-bar bg-<?= $occ>=90?'danger':($occ>=70?'warning':'success') ?>"
                                 style="width:<?= $occ ?>%"></div>
                        </div>
                        <strong><?= $occ ?>%</strong>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    </div>
</div>

<script>
document.getElementById('exportCsvBtn').addEventListener('click', function(e) {
    e.preventDefault();
    const table = document.getElementById('reportTable');
    if (!table) { alert('No data to export.'); return; }
    let csv = '';
    table.querySelectorAll('tr').forEach(row => {
        const cells = Array.from(row.querySelectorAll('th,td'));
        csv += cells.map(c => '"' + c.innerText.replace(/"/g, '""').replace(/\n/g,' ').trim() + '"').join(',') + '\n';
    });
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = '<?= e($report) ?>_report_<?= date('Ymd') ?>.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
